
<div class="min-h-[100dvh] flex items-center justify-center px-4 bg-[#0B5D3B]">
    <div class="w-full max-w-sm bg-white/95 backdrop-blur-xl p-6 sm:p-8 rounded-2xl shadow-xl">
        
        <div class="mb-6 text-center">
            
            
            <h2 class="text-2xl font-bold text-[#1F2937]">Login</h2>
            <p class="text-sm text-gray-500 mt-1">Masuk untuk melanjutkan</p>
        </div>

        
        <form wire:submit.prevent="login" class="space-y-4">
            
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                <input id="email" type="email" wire:model.defer="email" required
                       class="mt-2 w-full rounded-lg border border-gray-300 px-4 py-3 shadow-sm 
                              focus:outline-none focus:ring-2 focus:ring-[#7BB542]"
                       placeholder="you@email.com" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <input id="password" type="password" wire:model.defer="password" required
                       class="mt-2 w-full rounded-lg border border-gray-300 px-4 py-3 shadow-sm 
                              focus:outline-none focus:ring-2 focus:ring-[#7BB542]"
                       placeholder="••••••••" />
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <div class="flex items-center justify-between text-sm">
                <label class="inline-flex items-center gap-2 text-gray-700">
                    <input id="remember" type="checkbox" wire:model="remember"
                           class="rounded border-gray-300 focus:ring-2 focus:ring-[#7BB542]" />
                    Remember me
                </label>
                <!--[if BLOCK]><![endif]--><?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>" class="text-[#0B5D3B] hover:underline font-medium">Daftar</a>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            
            <button type="submit"
                    class="w-full flex justify-center py-3 px-4 text-sm font-semibold rounded-lg
                           text-white shadow-md transition
                           bg-[#7BB542] hover:bg-[#689a3b] focus:outline-none focus:ring-2 focus:ring-[#D4AF37]">
                Login
            </button>
        </form>

        
        <p class="mt-6 text-center text-xs text-[#D4AF37]">
            © <?php echo e(now()->year); ?> — UTC IOC / UPC
        </p>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\kp-lara\kp-utc\resources\views/livewire/auth/login.blade.php ENDPATH**/ ?>