<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\LapanganPanelProvider::class,
    App\Providers\Filament\ReservasiPanelProvider::class,
];
